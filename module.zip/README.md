# jogador-completao-5e
O completão do jogador de 5e para a fundição